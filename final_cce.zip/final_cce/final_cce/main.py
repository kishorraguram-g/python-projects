from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from predict import predict

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///login_data.db'

db = SQLAlchemy(app)

class Login(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(20), nullable=False)

@app.route('/')
def home():
    return render_template('frontpage.html')

@app.route('/process', methods=['POST'])
def process():
    sugar = int(request.form['sugar_level'])
    age = int(request.form['age'])
    sex = 1 if (request.form['gender']) == "male" else 0
    pressure = int(request.form['pressure'])
    chol = int(request.form['cholesterol'])
    
    result = predict(sugar=sugar, age=age, sex=sex, pressure=pressure, chol=chol)
    if result:
        msg = "You might have a heart disease"
        return render_template("hdietry.html", msg=msg)
    else:
        msg = "No heart disease threat found"
        return render_template("dietry.html", msg=msg)

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        Data = Login.query.order_by(Login.username).all()
        for i in Data:
            if i.username == username and i.password == password:
                return render_template('heartdiseasepredictor.html')
        else:
            return render_template('login.html', msg="Username or password is incorrect")
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        existing_user = Login.query.filter_by(username=username).first()
        if existing_user:
            msg = 'User Already Exits please choose a different user name'
            return render_template('register_page.html', msg=msg)
        
        new_user = Login(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        
        msg = "Registration Successful Please Login"
        return render_template('login.html', msg=msg)
    return render_template('register_page.html')

@app.route('/heartdiseasepredictor')
def heart():
    return render_template('heartdiseasepredictor.html')

@app.route('/contact')
def c():
    return render_template('contactus.html')

@app.route('/services')
def services():
    return render_template('our services.html')

@app.route('/team')
def team():
    return render_template('our team.html')

@app.route('/about')
def about():
    return render_template('about us.html')

@app.route('/diet')
def diet():
    return render_template('dietry.html')

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
