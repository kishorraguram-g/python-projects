import requests
from django.shortcuts import render

def home(request):
    return render(request, 'weather/home.html')

def get_weather(request):
    if request.method == 'GET':
        city = request.GET.get('city')
        api_key = '5871468e53c4a19e1a657e734a0f7edf'  # Replace with your actual OpenWeatherMap API key
        api_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric'
        response = requests.get(api_url)
        data = response.json()
        
        if data.get('cod') != 200:
            weather_data = {
                'city': city,
                'error': data.get('message', 'City not found')
            }
        else:
            weather_data = {
                'city': city,
                'temperature': data['main']['temp'],
                'description': data['weather'][0]['description'],
                'icon': data['weather'][0]['icon']
            }
        return render(request, 'weather/weather.html', {'weather': weather_data})
